/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import java.util.Scanner;

/**
 *
 * @author mezequielc
 */
public class ServiciosExcepciones {
    
    public void intentoAdivinar(int numeroUsuario, int numeroAdivinar){
       
        if (numeroUsuario==numeroAdivinar) {
            
            System.out.println("Encontraste el numero! "+numeroAdivinar);
            
            System.out.println("----");
        }else if(numeroUsuario>numeroAdivinar){
           
            System.out.println("El numero indicado es mayor al buscado");
            System.out.println("----");
        }else if (numeroUsuario<numeroAdivinar) {
            
            System.out.println("El numero indicado es MENOR al buscado");
            System.out.println("----");
        }
       
       
    }
}
