/*
La maquina genera un numero aleatorio y guia al usuario a encontrar ese numero, indicandole mayor o menor
Si se ingresa algo distinto a un numero por teclado se maneja el error 
*/


package excepcionesej5;

import Servicios.ServiciosExcepciones;
import static java.lang.Double.max;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Inicio {

    
    public static void main(String[] args) {
       Scanner leer=new Scanner(System.in);
        int max=500;
        int min=0;
        ServiciosExcepciones se = new ServiciosExcepciones();
        int numeroAdivinar=100;
      numeroAdivinar=(int) (Math.random()*(max - min)+min);
        
        
        int numeroUsuario=0;
        int intentos=0;
        System.out.println("Intenta adivinar el numero");
      
             try{
                
                 
                
            do {
                
                 numeroUsuario=leer.nextInt();
                intentos++;
                se.intentoAdivinar(numeroUsuario, numeroAdivinar);
            
                 if (numeroUsuario!=numeroAdivinar) {
                     System.out.println("ingrese otro numero");
                
                 } 
                
        } while (numeroUsuario!=numeroAdivinar);
             }catch (InputMismatchException a){
                    System.out.println("ERROR el caracter ingresado no es un numero");
                    intentos++;
                }
        
        
        
        
        if (numeroUsuario==numeroAdivinar) {
            System.out.println("El numero de intentos fue: "+intentos);
        }
        
        
       
        
    }
    
}
