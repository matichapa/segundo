
package gherenciaej2.inicio;

import Entidades.Electrodomestico;
import Entidades.Lavadora;
import Entidades.Televisor;
import java.util.ArrayList;


public class Inicio {

    
    public static void main(String[] args) {
        ArrayList<Electrodomestico>electrodomesticos=new ArrayList<Electrodomestico>();
       int precioTotal=0;
        
        
        //METODOS PARA TELEVISOR
        Televisor tv1=new Televisor(1000, "negro", "A", 10);
           tv1.crearTelevisor(tv1);
            tv1.precioFinal();
            System.out.println("TELEVISOR 1");
            tv1.imprimirResultados();
            
           electrodomesticos.add(tv1);//INGRESO EL PRIMER TELEVISOR
           System.out.println("--------");
           
           Televisor tv2=new Televisor(1000, "gris", "D", 20);
           tv2.crearTelevisor(tv2);
            tv2.precioFinal();
            System.out.println("TELEVISOR 2");
            tv2.imprimirResultados();
            
           electrodomesticos.add(tv2);//INGRESO EL SEGUNDO TELEVISOR
           System.out.println("--------");
            
       Lavadora lav1=new Lavadora(1000, "rojo", "A", 70);
             lav1.crearLavadora(lav1);
             lav1.precioFinal();
             System.out.println("LAVADORA 1");
             lav1.imprimirResultados();
             System.out.println("---------");
             
             electrodomesticos.add(lav1);//INGRESO LA PRIMER LAVADORA
   
            Lavadora lav2=new Lavadora(1000, "azul", "B", 30);
             lav2.crearLavadora(lav2);
             lav2.precioFinal();
             System.out.println("LAVADORA 2");
             lav2.imprimirResultados();
           
             electrodomesticos.add(lav2);//INGRESO SEGUNDA LAVADORA
             System.out.println("------");
             System.out.println(" ");
       
             
        /* for (Electrodomestico aux : electrodomesticos) {
            aux.precioFinal();
            aux.imprimirResultados();
            
                        
             System.out.println("----");
        }*/
            
        }
    }
    

