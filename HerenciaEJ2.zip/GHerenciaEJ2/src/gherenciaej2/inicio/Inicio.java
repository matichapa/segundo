
package gherenciaej2.inicio;

import Entidades.Electrodomestico;
import Entidades.Lavadora;
import Entidades.Televisor;


public class Inicio {

    
    public static void main(String[] args) {
        
        //METODOS PARA TELEVISOR
        Televisor tv1=new Televisor(1000, "negro", "A", 10);
           tv1.crearTelevisor(tv1);
            tv1.precioFinal();
            System.out.println("TELEVISOR");
            tv1.imprimirResultados();
           
           System.out.println("--------");
            
       Lavadora lav1=new Lavadora(1000, "rojo", "A", 70);
            
            
             lav1.crearLavadora(lav1);
             lav1.precioFinal();
             System.out.println("LAVADORA");
             lav1.imprimirResultados();
     
      
   
       
    }
    
}
