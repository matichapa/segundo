/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author mezequielc
 */
public class Televisor extends Electrodomestico {
    
    private double resolucion;
    private boolean sintonizador;

    //USO EL CONSTRUCTOR DE ELECTRODOMESTICOS Y AGREGO LOS ATRIBUTOS QUE NECESITO
    public Televisor(int precio, String color, String consumoEnergetico, double peso) {
        super(precio, color, consumoEnergetico, peso);
        this.resolucion = resolucion;
        this.sintonizador = sintonizador;
        
    }

    public double getResolucion() {
        return resolucion;
    }

    public void setResolucion(double resolucion) {
        this.resolucion = resolucion;
    }

    public boolean isSintonizador() {
        return sintonizador;
    }

    public void setSintonizador(boolean sintonizador) {
        this.sintonizador = sintonizador;
    }
  
    //CREAR EL TELEVISOR LLAMANDO AL METODO HEREDADO DE ELECTRODOMESTICO
    public void crearTelevisor(Televisor tv1){
        
        super.crearElectrodomestico(tv1);
        tv1.setResolucion(50);
        tv1.setSintonizador(false);
        
        
    }

    
    //UTILIZA EL METODO DE PRECIO FINAL (DE ELECTRODOMESTICO) Y SOBREESCRIBE DEPENDIENDO LAS NECESIDADES
    @Override
    public void precioFinal() {
       int porcentaje;
        super.precioFinal(); 
        if (resolucion>40) {
                
            porcentaje=(precio*30)/100;
            precio=precio+porcentaje;
        }else if (sintonizador==true) {
            precio=precio+500;
        }
    }
    
   
}
