
package Entidades;

import java.util.ArrayList;


public class Electrodomestico {
    
    protected int precio; 
    protected String color;
    protected String consumoEnergetico;
    protected double peso; 
    ArrayList<String> letra = new ArrayList<String>();
    ArrayList<String> colores = new ArrayList<String>();
    

    public Electrodomestico() {
    }

    // CONSTRUCTOR BASE DEL EJERCICIO (TODAS LAS CLASES CONTENDRAN COMO MINIMO ESTOS ATRIBUTOS
    public Electrodomestico(int precio, String color, String consumoEnergetico, double peso) {
        this.precio = precio;
        this.color = color;
        this.consumoEnergetico = consumoEnergetico;
        this.peso = peso;
    }

   
 // CREAR EL ELECTRODOMESTICO Y LLAMA A LOS METODOS QUE COMPRUEBAN EL COLOR Y EL CONSUMO ENERGETICO
    public Electrodomestico crearElectrodomestico(Electrodomestico ele1){
        
        ele1.comprobarColor();
        ele1.comprobarConsumoEnergetico();
        
        return ele1;
        
    } 
   
    //COMPRUEBA CONSUMO ENERGETICO CON UN ARRAY
    public void comprobarConsumoEnergetico(){
        // INGRESAN LOS VALORES EN EL ARRAY LIST
       letra.add("A");
       letra.add("B");
       letra.add("C");
       letra.add("D");
       letra.add("E");
       letra.add("F");
       
        /* COMPARA LA LETRA DEL CONSUMO CONTRA EL ARRAY LIST ENTERO EN UNA SOLA LINEA (LINEA 76)*/
        if (letra.contains(consumoEnergetico)) {
            consumoEnergetico=consumoEnergetico;
        }else {
            consumoEnergetico="F";
        }
        
        
    }
    
    //COMPRUEBA COLOR CON UN ARRAY
    public void comprobarColor(){
        colores.add("blanco");
        colores.add("negro");
        colores.add("azul");
        colores.add("gris");
        colores.add("rojo");
        
         /* COMPARA LA LETRA DEL CONSUMO CONTRA EL ARRAY LIST ENTERO EN UNA SOLA LINEA (LINEA 76)*/
        if (colores.contains(color)) {
            color=color;
        }else {
            color="blanco";
        }
    
       
        
    }
    
   
    
    //METODO BASE CON EL QUE SE CALCULA EL PRECIO FINAL(CADA CLASE SOBREESCRIBIRA DEPENDIENDO SUS NECESIDADES)
    public void precioFinal(){
        
        // PRECIO POR LETRA  
        switch (consumoEnergetico){
            case "A":
                precio=1000;
                break;
            case "B": 
                precio=800;
                break;                
            case "C":
                precio=600;
                break;   
            case "D":
                precio=500;
                break;  
            case "E":
                precio=300;
                break;  
            case "F":
                precio=100;
                break;
            default:
                precio=100;
        }
       
        //PRECIO POR KILOGRAMO
        if (peso>0 && peso<=19) {
            precio=precio+100;
        }else if (peso>19 && peso<=49) {
            precio=precio+500;
        }else if (peso>49 && peso<=79) {
            precio=precio+800;
        }else if (peso>=80) {
            precio=precio+1000;
        }
        
        
    }
    
    public void imprimirResultados(){
        System.out.println("Color: "+color);
        System.out.println("Consumo: "+consumoEnergetico);
        System.out.println("Precio Final: "+precio);
    }

}
