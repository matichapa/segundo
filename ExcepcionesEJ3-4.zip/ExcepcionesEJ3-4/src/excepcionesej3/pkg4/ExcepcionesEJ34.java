
package excepcionesej3.pkg4;

import Servicios.ServiciosExcepciones;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ExcepcionesEJ34 {

   
    public static void main(String[] args) {
       String n1="";
       int numero1=0;
       int numero2=0;
        ServiciosExcepciones se=new ServiciosExcepciones();
       
       
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese dos numeros");
        
        try {
            se.lecturaNumero();   
        }catch (NumberFormatException a){
            System.out.println("ERROR");
        }

       
     
        
            
    }
    
    
    
}
