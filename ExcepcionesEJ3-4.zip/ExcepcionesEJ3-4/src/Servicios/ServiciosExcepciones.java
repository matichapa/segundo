/*
Este ejercicio recibe dos numeros en caracters de STRING
los convierte en INT y luego los divide entre si. 
Maneja 3 tipos de errores 
 */
package Servicios;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


public class ServiciosExcepciones {
    public void lecturaNumero() throws InputMismatchException{
        ServiciosExcepciones sv=new ServiciosExcepciones();
      
        Scanner leer=new Scanner(System.in);
        String n1="";
        String n2="";
       
   
        n1=leer.nextLine();
        n2=leer.nextLine();
       
        
        try{
             sv.convertirNumeros(n1, n2);
        }catch (NumberFormatException a){
            System.out.println("ERROR Los numeros deben de ser enteros");
        }
       
    }
    public void convertirNumeros(String n1, String n2)throws NumberFormatException{
        ServiciosExcepciones sv=new ServiciosExcepciones();
        
        int numero1=0;
       int numero2=0;
        
        numero1=Integer.parseInt(n1);
        numero2=Integer.parseInt(n2);
        System.out.println("------");
        
        try{
             sv.division(numero1, numero2);
        }catch(ArithmeticException a){
            System.out.println("ERROR un numero no puede ser dividido por 0");
        }
       
    }
    
    public void division(int numero1, int numero2)throws ArithmeticException{
       
        int division=numero1/numero2;
        System.out.println("El resultado de la division es: "+division);
        
        
        
        
    }
}
